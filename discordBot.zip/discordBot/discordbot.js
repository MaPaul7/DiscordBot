require('dotenv').config();

// Discord.js versions ^13.0 require us to explicitly define client intents
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds], partials: [Partials.Channel] });

client.on('ready', () => {
 console.log(`Logged in as ${client.user.tag}!`);
});
// Log In our bot
client.login(process.env.CLIENT_TOKEN);

client.on('messageCreate', msg => {
  //console.log(msg);
  //console.log("Wrote something");
// You can view the msg object here with console.log(msg)
 if (msg.content === 'Hello') {
   msg.reply(`Hi ${msg.author.username}`);
 }
 if (msg.content === 'Goodbye') {
   msg.reply(`Bye ${msg.author.username}`);
 }
});
