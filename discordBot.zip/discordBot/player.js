const mongoose = require('mongoose');

const player = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  pokeballs: {
    type: String,
    required: true,
  },
  premierballs: {
    type: String,
    required: true,
  },
  greatballs: {
    type: String,
    required: true,
  },
  ultraballs: {
    type: String,
    required: true,
  },
  masterballs: {
    type: String,
    required: true,
  },
  coins: {
    type: String,
    required: true,
  },
  items: {
    type: Object,
    required: true,
  }

})

module.exports = mongoose.model('testing2', player)
