const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  species: {
    type: String,
    required: true,
  },
  typing: {
    type: String,
    required: true,
  },
  shiny: {
    type: Boolean,
    required: true,
  },
  trainer: {
    type: String,
    required: false,
  },
  evs: {
    type: Object,
    required: true,
  },
  ivs: {
    type: Object,
    required: true,
  },
  nature: {
    type: String,
    required: true,
  },
  number: {
    type: String,
    required: true,
  },
  level: {
    type: String,
    required: true,
  }

})

module.exports = mongoose.model('testing', schema)
