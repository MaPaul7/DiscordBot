require('dotenv').config(); //initialize dotenv
const {ActionRowBuilder, Client, PermissionsBitField, GatewayIntentBits, Events, ButtonBuilder, ButtonStyle, SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder}  = require('discord.js'); //import discord.js
const { request } = require('undici');
const mongoose = require('mongoose');

const testSchema = require('./test-schema');
const player = require('./player');
const client = new Client({ intents: [ GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]});
const guild = client.guilds.cache.get("GUILD_ID");

const attack = ["Lonely", "Adamant", "Naughty", "Brave"];
const deffense = ["Bold", "Impish", "Lax", "Relaxed"];
const spattack = ["Modest", "Mild", "Rash", "Quiet"];
const spdeff = ["Calm", "Gentle", "Careful", "Sassy"];
const speed = ["Timid",	"Hasty", "Jolly",	"Naive"];

const natures = ["Hardy", "Lonely",	"Adamant", "Naughty", "Brave", "Bold", "Docile", "Impish", "Lax",	"Relaxed", "Modest", "Mild", "Bashful", "Rash", "Quiet", "Calm",	"Gentle",	"Careful", "Quirky", "Sassy", "Timid", "Hasty", "Jolly", "Naive", "Serious"];

const mattack = ["Bold", "Modest", "Calm", "Timid"];
const mdeffense = ["Lonely", "Mild", "Gentle", "Hasty"];
const mspattack = ["Adamant", "Impish", "Careful", "Jolly"];
const mspdeff = ["Naughty", "Lax", "Rash", "Naive"];
const mspeed = ["Brave",	"Relaxed", "Quiet",	"Sassy"];

let nature = "";
let nickname = "";

let starters = ["Bulbasaur", "Charmander", "Squirtle", "Chikorita", "Cyndaquil", "Totodile", "Treecko", "Torchic", "Mudkip", "Turtwig", "Chimchar", "Piplup",
"Snivy", "Tepig", "Oshawott", "Chespin", "Fennekin", "Froakie", "Rowlet", "Litten", "Popplio", "Grookey", "Scorbunny", "Sobble", "Sprigatito", "Fuecoco", "Quaxly"];

let starter = "";
let startergen = 0;

let hpiv = 0;
let attiv = 0;
let deffiv = 0;
let spattiv = 0;
let spdefiv = 0;
let speediv = 0;

let evsarr = [0,0,0,0,0,0];
let ivsarr = [0,0,0,0,0,0];

let earlypokes = [10, 13, 16, 19, 21, 161, 163, 165, 167, 261, 263, 265, 270, 273, 276, 278,
  283, 397, 399, 401, 403, 504, 506, 509, 519, 659, 661, 664, 667, 731, 734, 736,
  819, 821, 824, 827, 915, 917, 919];

let strongpokes = [149, 248, 376, 373, 445, 635, 706, 784, 887, 998,
  1018, 681, 637, 612, 306, 330, 94, 130, 65, 59]

let bag = new Array(1);
bag[0] = ["Potion", 1];

const trim = (str, max) => (str.length > max ? `${str.slice(0, max - 3)}...` : str);

client.on(Events.ClientReady, () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('ready', async () => {
  await mongoose.connect (process.env.MONGO_URI, {
    keepAlive : true,
  })
})

/*client.on('guildMemberAdd', (member) => {
  console.log("Hi");
  member.guild.channels.get('channelID').send("Welcome");
});*/

let name = "";
let type = "";
let shinyBool = false;
let generated = "";
let number = "";

client.on('messageCreate', async msg => {

 let prefix = msg.content.substring(0,1);
 let cont = msg.content.substring(1);

 if(prefix === '-'){
   if (cont === 'Hello' || cont === 'hello') {
     if(msg.channel.id == '1097227005818327140'){
       msg.reply(`Hi ${msg.author.username}`);
     }
     else{
       client.channels.cache.get('1097227005818327140').send(`Hi ${msg.author.username}`);
     }
   }
   if (cont === 'Goodbye' || cont === 'goodbye') {
     if(msg.channel.id == '1097227005818327140'){
       msg.reply(`Bye ${msg.author.username}`);
     }
     else{
       client.channels.cache.get('1097227005818327140').send(`Bye ${msg.author.username}`);
     }
   }
   if(cont == "help"){
     const help_embed = {
      title: 'Commands',
     fields: [
   {
     name: 'Stats',
     value: '-bag: View your items \n-register: Add yourself to the game \n-random_poke: Generate a random pokemon \n-catch: Brings up the catch menu \n-view_party: See your list of party pokemon\n' +
     '-shop: View items for sale \n-buy [item] [amount]: Buy amount of specified item \n-toss [item] [amount]: Toss amount of specified item \n'
    +'-release [pokemon]: Release the given pokemon',
   },
 ],
    };
    msg.reply({
      embeds: [help_embed],
      ephemeral: false
    });
   }
   if(cont.startsWith("evolve")){
     let arr = cont.split(" ");
     const pokes = await testSchema.find({trainer : msg.author.username});
     let found = false;
     let f = arr[1].substring(0,1);
     let r = arr[1].substring(1);
     arr[1] = f.toUpperCase() + r;
     let condition = false;
     for(let i = 0; i< pokes.length; i++){
       if(pokes[i].name == arr[1]){
         let evoPoke = pokes[i];
         arr[1] = arr[1].toLowerCase();
         found = true;
         let req = 'https://pokeapi.co/api/v2/pokemon-species/' + arr[1];
         const results = await request(req);
         const nresults = await results.body.json();
         const myJSON = JSON.stringify(nresults);

         f = arr[1].substring(0,1);
         r = arr[1].substring(1);
         let poke1 = f.toUpperCase() + r;

         arr1 = myJSON.split(",");
         for(let i = 5; i < 9; i++){
           if(arr1[i].substring(1,10) == "evolution"){
            let req2 = arr1[i].substring(26, arr1[i].length-2);

            const results2 = await request(req2);
            const nresults2 = await results2.body.json();
            const myJSON2 = JSON.stringify(nresults2);

            let arr2 = myJSON2.split(",");
            let evo_line = ""
            for(let j = 0; j < arr2.length; j++){
              if(arr2[j].includes("species") && arr2[j].includes("name")){
                evo_line+= arr2[j].substring(19, arr2[j].length-1);
                evo_line+= " ";
              }
            }
            let evo_data = "";
            for(let j = 0; j < arr2.length; j++){
              evo_data+= arr2[j];
              evo_data+= " ";
            }
            let arr4 = evo_data.split(" ");
            for(let j = 0; j < arr4.length; j++){
              if(arr4[j].includes("null")){
                arr4[j] = "";
              }
            }
            for(let j = 0; j < arr4.length; j++){
              if(arr4[j].includes("min_level")){
                if(parseInt(arr4[j].substring(12)) <= parseInt(evoPoke.level)){
                  condition = true;
                  let arr3 = evo_line.split(" ");
                  for(let x = 0; x < arr3.length; x++){
                    if(arr3[x] == arr[1]){
                    if(condition == true && x > 0){

                      let newName = arr3[x-1];
                      let fp = newName.substring(0,1);
                      let rp = newName.substring(1);
                      fp = fp.toUpperCase();
                      newName = fp + rp;

                      client.channels.cache.get('1097227005818327140').send("Your " + evoPoke.name + " evolved into " + newName);
                      let req3 = 'https://pokeapi.co/api/v2/pokemon/' + arr3[x-1];
                      const results3 = await request(req3);
                      const nresults3 = await results3.body.json();
                      const myJSON3 = JSON.stringify(nresults3);

                      let type1 = "";
                      let type2 = "";
                      let fl = "";
                      arr5 = myJSON3.split(",");
                      for(let i = 0; i < arr5.length; i++){
                        if(arr5[i].substring(0,6) === '"type"'){
                          if(type1 == ""){
                            type1 = arr5[i].substring(16, arr5[i].length-1);
                            fl = type1.substring(0,1);
                            fl = fl.toUpperCase();
                            type1 = fl + type1.substring(1);
                          }else{
                            type2 = arr5[i].substring(16, arr5[i].length-1);
                            fl = type2.substring(0,1);
                            fl = fl.toUpperCase();
                            type2 = fl + type2.substring(1);
                          }
                          if(type2 == ""){
                            type = type1;
                          }else{
                            type = type1 + "/" + type2;
                          }

                        }
                      }

                      let newNumber = parseInt(evoPoke.number) + 1

                      await testSchema.updateOne({name : evoPoke.name}, {$set: {number: newNumber}});
                      await testSchema.updateOne({name : evoPoke.name}, {$set: {typing: type}});
                      await testSchema.updateOne({name : evoPoke.name}, {$set: {species: newName}});
                      await testSchema.updateOne({name : evoPoke.name}, {$set: {name: newName}});

                    }
                    else if(condition == true && x == 0){
                        client.channels.cache.get('1097227005818327140').send("Your " + evoPoke.name + " can't evolve any further");
                    }
                    else{
                      client.channels.cache.get('1097227005818327140').send("Your pokemon cannot evolve right now");

                    }
                  }
                }
              }else{
                client.channels.cache.get('1097227005818327140').send("Your pokemon cannot evolve right now");
              }
            }
            else if(arr4[j].includes('item":{"name"')){

                let arr3 = evo_line.split(" ");
                let newName = "";
                let lName = "";
                for(let x = 0; x < arr3.length; x++){
                    if(arr3[x] == arr[1]){
                      lName = arr3[x-1];
                      let fp = lName.substring(0,1);
                      let rp = lName.substring(1);
                      fp = fp.toUpperCase();
                      newName = fp + rp;
                    }
                }

                n_item = arr4[j].substring(16,arr4[j].length-1);
                const user = await player.find({name : msg.author.username});
                let arr6 = user[0].items;
                let gotItem = false
                for(let i = 0; i < user[0].items.length; i++){
                  if(arr6[i][0] == n_item && arr6[i][1] > 0){
                    gotItem = true;
                    client.channels.cache.get('1097227005818327140').send("Your " + evoPoke.name + " evolved into " +  newName);
                    arr6[i][1]--;
                    await player.updateOne({name : user[0].name}, {$set: {items: arr6}});
                    let req3 = 'https://pokeapi.co/api/v2/pokemon/' + lName;
                    const results3 = await request(req3);
                    const nresults3 = await results3.body.json();
                    const myJSON3 = JSON.stringify(nresults3);
                    let type1 = "";
                    let type2 = "";
                    let fl = "";
                    arr5 = myJSON3.split(",");
                    for(let i = 0; i < arr5.length; i++){
                      if(arr5[i].substring(0,6) === '"type"'){
                        if(type1 == ""){
                          type1 = arr5[i].substring(16, arr5[i].length-1);
                          fl = type1.substring(0,1);
                          fl = fl.toUpperCase();
                          type1 = fl + type1.substring(1);
                        }else{
                          type2 = arr5[i].substring(16, arr5[i].length-1);
                          fl = type2.substring(0,1);
                          fl = fl.toUpperCase();
                          type2 = fl + type2.substring(1);
                        }
                        if(type2 == ""){
                          type = type1;
                        }else{
                          type = type1 + "/" + type2;
                        }

                      }
                    }
                    let newNumber = parseInt(evoPoke.number) + 1

                    await testSchema.updateOne({name : evoPoke.name}, {$set: {number: newNumber}});
                    await testSchema.updateOne({name : evoPoke.name}, {$set: {typing: type}});
                    await testSchema.updateOne({name : evoPoke.name}, {$set: {species: newName}});
                    await testSchema.updateOne({name : evoPoke.name}, {$set: {name: newName}});
                  }
                }

                if(gotItem == false){
                  client.channels.cache.get('1097227005818327140').send("Item needed for evolution");
                }
            }
          }
        }
      }
    }
   }if(found == false){
     client.channels.cache.get('1097227005818327140').send("Pokemon " + arr[1] + " not found.");
   }

   }
   if(cont.startsWith("give_item")){
     let arr1 = cont.split(" ");

     const user = await player.find({name : msg.author.username});
     let arr2 = user[0].items;
     let addNum = 1;
     if(arr1.length > 2){
       addNum = parseInt(arr1[2]);
     }
     let found = false;
     for(let i = 0; i < arr2.length; i++){
       if(arr2[i][0] == arr1[1]){
         found = true;
         let num = arr2[i][1];
         num = parseInt(num) + parseInt(addNum);
         arr2[i][1] = num;
         await player.updateOne({name : user[0].name}, {$set: {items: arr2}});
         if(addNum > 1){
           client.channels.cache.get('1097227005818327140').send("Added " + addNum + " " + arr1[1] + "s to your bag");
         }
         else{
           client.channels.cache.get('1097227005818327140').send("Added one " + arr1[1] + " to your bag");
         }
       }
     }
     let arr3 = new Array(arr2.length + 1);
     if(found == false){
       for(let i = 0; i < arr2.length; i++){
         arr3[i] = arr2[i];
       }
       arr3[arr3.length-1] = [arr1[1], addNum];
       await player.updateOne({name : user[0].name}, {$set: {items: arr3}});
       if(addNum > 1){
         client.channels.cache.get('1097227005818327140').send("Added " + addNum + " " + arr1[1] + "s to your bag");
       }else{
         client.channels.cache.get('1097227005818327140').send("Added one " + arr1[1] + " to your bag");
       }
    }
   }
   if(cont.startsWith("level_up")){
     let arr1 = cont.split(" ");
     let f = arr1[1].substring(0,1);
     let r = arr1[1].substring(1);
     f = f.toUpperCase();
     let n = f + r;
     const pokes = await testSchema.find({trainer : msg.author.username});
     const users = await player.find({name : msg.author.username});
     let lc = 1;
     if(arr1.length > 2){
       lc = arr1[2];
     }
     let user = users[0];
     let arr2 = user.items;
     for(let i = 0; i<arr2.length; i++){
       if(arr2[i][0] == "rare-candy"){
         if(arr2[i][1] >= lc){
           arr2[i][1] = arr2[i][1] - lc;
           if(arr2[i][1] == 0){
             arr2.splice(i,1);
           }
           for(let i = 0; i< pokes.length; i++){
             if(pokes[i].name == n){
               let newLevel = parseInt(pokes[i].level) + lc
               if(newLevel > 100){
                 if(users[0].name != "relativemax" && users[0].name != "shluffymonster"){
                   client.channels.cache.get('1097227005818327140').send("Cannot level past 100");
                 }else{
                   await testSchema.updateOne({name : n}, {$set: {level: parseInt(pokes[i].level) + lc}});
                   await player.updateOne({name : user.name}, {$set: {items: arr2}});
                   if(lc == 1){
                     client.channels.cache.get('1097227005818327140').send("Leveled up " + pokes[i].name + " 1 time");
                   }
                   else{
                     client.channels.cache.get('1097227005818327140').send("Leveled up " + pokes[i].name + " " + lc + " times");
                   }

                 }
               }
               else{
                 await testSchema.updateOne({name : n}, {$set: {level: parseInt(pokes[i].level) + lc}});
                 await player.updateOne({name : user.name}, {$set: {items: arr2}});
                 if(lc == 1){
                   client.channels.cache.get('1097227005818327140').send("Leveled up " + pokes[i].name + " 1 time");
                 }
                 else{
                   client.channels.cache.get('1097227005818327140').send("Leveled up " + pokes[i].name + " " + lc + " times");
                 }
               }
            }
           }
         }else{
           client.channels.cache.get('1097227005818327140').send("Not enough rare candies");
         }
       }
     }

   }

   if(cont.startsWith("set_level")){
     let arr1 = cont.split(" ");
     let f = arr1[1].substring(0,1);
     let r = arr1[1].substring(1);
     f = f.toUpperCase();
     let n = f + r;
     const pokes = await testSchema.find({trainer : msg.author.username});
     for(let i = 0; i< pokes.length; i++){
       if(pokes[i].name == n){
         await testSchema.updateOne({name : n}, {$set: {level: arr1[2]}});
         client.channels.cache.get('1097227005818327140').send("Set " + pokes[i].name + "'s" + " level to " + arr1[2]);

       }
     }
   }
   if(cont.startsWith("view_bag")){
     const users = await player.find({name : msg.author.username});
     let user = users[0];
     let l = "";
     if(user.items.length == 0){
       client.channels.cache.get('1097227005818327140').send("Bag is empty");
     }
     else{
       for(let i = 0; i < user.items.length; i++){
         l += user.items[i][0] + ": " + user.items[i][1] + "\n";
        }
        client.channels.cache.get('1097227005818327140').send(l);
     }
   }
   if(cont.startsWith("starter")){
     const pokes = await testSchema.find({trainer : msg.author.username});

     if(pokes.length >= 6){
       client.channels.cache.get('1097227005818327140').send("You already have a full party!");
     }else{
       if(cont.split(" ").length == 2){
         let arr = cont.split(" ");
         let gen = parseInt(arr[1]);
         if(gen == 1 || gen == 2 || gen == 3 || gen == 4 || gen == 5 || gen == 6 || gen == 7 || gen == 8 || gen == 9){
           startergen = gen;
           const Grass = new ButtonBuilder()
           .setCustomId('Grass')
           .setLabel(starters[(gen-1)*3])
           .setStyle(ButtonStyle.Success);
           const Fire = new ButtonBuilder()
           .setCustomId('Fire')
           .setLabel(starters[(gen-1)*3 + 1])
           .setStyle(ButtonStyle.Danger);
           const Water = new ButtonBuilder()
           .setCustomId('Water')
           .setLabel(starters[(gen-1)*3 + 2])
           .setStyle(ButtonStyle.Primary);

           const row = new ActionRowBuilder().addComponents(Grass, Fire, Water);

             const messageObject = {
               content: "Select a starter",
               components: [row]
             }
              client.channels.cache.get('1097227005818327140').send(messageObject);
         }
         else{
           client.channels.cache.get('1097227005818327140').send("Please enter a valid generation");
         }

       }
       else{
         client.channels.cache.get('1097227005818327140').send("Please specify which generation");
       }
     }
   }

   if(cont.startsWith("givex")){
     let arr = cont.split(" ");
     if(arr.length == 2){
       let amount = arr[1];
       const user = await player.find({name : msg.author.username});
       let curr = user[0].coins;
       let total = parseInt(curr) + parseInt(amount);

       let name = user[0].name;

       await player.updateOne({name : name}, {$set: {coins: parseInt(total)}});

       client.channels.cache.get('1097227005818327140').send("Given " + amount + " coins. You now have "+ parseInt(total) +" coins in total");

     }else{
       msg.reply("Invalid give");
     }
   }
   if(cont.startsWith("removecoins")){
     let arr = cont.split(" ");
     if(arr.length == 2){
       let amount = arr[1];
       const user = await player.find({name : msg.author.username});
       let curr = user[0].coins;
       let total = parseInt(curr) - parseInt(amount);
       if(total < 0) total = 0;

       let name = user[0].name;

       await player.updateOne({name : name}, {$set: {coins: parseInt(total)}});

       client.channels.cache.get('1097227005818327140').send("Taken " + amount + " coins. You now have "+ parseInt(total) +" coins in total");

     }else{
       msg.reply("Invalid give");
     }
   }
   if(cont == "register" || cont == "Register"){
     client.channels.cache.get('1097227005818327140').send("Added " + msg.author.username + " as a new player");
     new player({
       name: msg.author.username,
       pokeballs: '0',
       premierballs: '0',
       greatballs: '0',
       ultraballs: '0',
       masterballs: '0',
       coins: '0',
       items: bag,
     }).save()

   }
   if(cont == "Bag" || cont == "bag"){
     const user = await player.find({name : msg.author.username});
     client.channels.cache.get('1097227005818327140').send("" + user[0].name + "'s bag: \nPokeballs: " + user[0].pokeballs + "\nPremier Balls: " + user[0].premierballs + "\nGreat Balls: " + user[0].greatballs +
     "\nUltra Balls: " + user[0].ultraballs + "\nMaster Balls: " + user[0].masterballs + "\nCoins: " + user[0].coins);
   }

   if(cont == "shop" || cont == "Shop"){

    client.channels.cache.get('1097227005818327140').send("Pokeballs: 200\nGreatBalls: 600\nUltraBalls: 800");
   }

   if(cont.startsWith("Buy") || cont.startsWith("buy")){
     let arr = cont.split(" ");
     if(arr.length != 3){
       client.channels.cache.get('1097227005818327140').send("Please enter a valid command (-buy item amount)");
     }
     else{
       const pokes = await player.find({name : msg.author.username});
       let name = msg.author.username;
       let item = arr[1];
       let num = arr[2];

       let curr = "";
       let total = 0;
       let premier = 0;
       let cost = 0;
       let afforded = true;
       let remaining = 0;

       let mast = Math.floor(Math.random() * 1000);

       if(item == "pokeball"){
         cost = parseInt(num) * 200;
         curr = pokes[0].pokeballs;
         total = parseInt(num)+ parseInt(curr);
         if(total > 999)total = 999;
         if(cost <= pokes[0].coins){
           remaining = pokes[0].coins - cost
           await player.updateOne({name : name}, {$set: {pokeballs: total}});
           await player.updateOne({name : name}, {$set: {coins: remaining}});
         }
         else{
           afforded = false;
         }

       }
       if(item == "greatball"){
         cost = parseInt(num) * 600;
         curr = pokes[0].greatballs;
         total = parseInt(num)+ parseInt(curr);
         if(total > 999) total = 999;
         if(cost <= pokes[0].coins){
           remaining = pokes[0].coins - cost
           await player.updateOne({name : name}, {$set: {greatballs: total}});
           await player.updateOne({name : name}, {$set: {coins: remaining}});
         }
         else{
           afforded = false;
         }
       }
       if(item == "ultraball"){
         cost = parseInt(num) * 1000;
         curr = pokes[0].ultraballs;
         total = parseInt(num)+ parseInt(curr);
         if(total > 999)total = 999;
         if(cost <= pokes[0].coins){
           remaining = pokes[0].coins - cost
           await player.updateOne({name : name}, {$set: {ultraballs: total}});
           await player.updateOne({name : name}, {$set: {coins: remaining}});
         }
         else{
           afforded = false;
         }
       }
       if(afforded == false){
         client.channels.cache.get('1097227005818327140').send("You don't have enough money");
       }
       else{
         let purchased = total-curr;
         if(purchased >= 10){
           premier = Math.floor(purchased/10);
         }
         if(purchased == 1){
           client.channels.cache.get('1097227005818327140').send("Successfully purchased " + purchased + " " + item);
         }
         else if(purchased == 0){
           client.channels.cache.get('1097227005818327140').send("Successfully purchased... nothing");
         }
         else{
           if(item == "pokeball") client.channels.cache.get('1097227005818327140').send("Successfully purchased " + purchased + " pokeballs <:pokeball:1157515551585878136>, you now have " + total +  " pokeballs.");
           else{
             client.channels.cache.get('1097227005818327140').send("Successfully purchased " + num + " " + item + "s");
           }
         }
         if(premier > 0){
           curr = pokes[0].premierballs;
           total = parseInt(premier) + parseInt(curr);
           if(total > 999) total = 999;
           await player.updateOne({name : name}, {$set: {premierballs: total}});
           client.channels.cache.get('1097227005818327140').send("You also received " + premier + " premier balls as an added bonus");

         }
         if(mast == 500){
          curr = pokes[0].masterballs;
          if(curr < 999){
            total = parseInt(curr) + 1;
            await player.updateOne({name : name}, {$set: {masterballs: total}});
            client.channels.cache.get('1097227005818327140').send("You also received a master ball");
          }
         }
       }
     }
   }
   if(cont.startsWith("Toss") || cont.startsWith("toss")){
     let arr = cont.split(" ");
     if(arr.length != 3){
       client.channels.cache.get('1097227005818327140').send("Please enter a valid command (-buy item amount)");
     }
     else{
       const pokes = await player.find({name : msg.author.username});
       let name = msg.author.username;
       let item = arr[1];
       let num = arr[2];

       let curr = "";
       let total = 0;

       if(item == "pokeball"){
         curr = pokes[0].pokeballs;
         diff = parseInt(curr) - parseInt(num);
         if(diff < 0)diff = 0;
         await player.updateOne({name : name}, {$set: {pokeballs: diff}});
       }
       if(item == "premierballs"){
         curr = pokes[0].premierballs;
         diff = parseInt(curr) - parseInt(num);
         if(diff < 0)diff = 0;
         await player.updateOne({name : name}, {$set: {premierballs: diff}});
       }
       if(item == "greatball"){
         curr = pokes[0].greatballs;
         diff = parseInt(curr) - parseInt(num);
         if(diff < 0) diff = 0;

         await player.updateOne({name : name}, {$set: {greatballs: diff}});
       }
       if(item == "ultraball"){
         curr = pokes[0].ultraballs;
         diff = parseInt(curr) - parseInt(num);
         if(diff < 0)diff = 0;
         await player.updateOne({name : name}, {$set: {ultraballs: diff}});
       }
       if(item == "masterball"){
         curr = pokes[0].masterballs;
         diff = parseInt(curr) - parseInt(num);
         if(diff < 0)diff = 0;
         await player.updateOne({name : name}, {$set: {masterballs: diff}});
       }else{

         const user = await player.find({name : msg.author.username});
         let arr2 = user[0].items;
         let gotItem = false;

         for(let i = 0; i < arr2.length; i++){
           if(arr2[i][0] == item){
             gotItem = true;
             if(arr2[i][1] >= num){
               arr2[i][1] = arr2[i][1] - num;
               if(arr2[i][1] == 0){
                 arr2.splice(i,1);
               }
               await player.updateOne({name : user[0].name}, {$set: {items: arr2}});
             }else{
               client.channels.cache.get('1097227005818327140').send("Cannot remove " + num + " items. Player has " + arr2[i][1] + " in their inventory");
             }
           }
         }
         if(gotItem == false){
           client.channels.cache.get('1097227005818327140').send("Player does not have any " + item + "s");
         }
       }
       if(num == "1"){
         client.channels.cache.get('1097227005818327140').send("Threw away " + num + " " + item);
       }
       else if(num == "0"){
         client.channels.cache.get('1097227005818327140').send("Threw away... nothing");
       }
       else{
         if(item == "pokeball") client.channels.cache.get('1097227005818327140').send("Threw away " + num + " pokeballs <:pokeball:1157515551585878136>, you now have " + diff +  " pokeballs.");
         else{
           console.log(item.substring(item.length-1));
           client.channels.cache.get('1097227005818327140').send("Threw away " + num + " " + item + "s");
         }
       }

     }

   }
   if(cont == 'view_party'){

     const pokes = await testSchema.find({trainer : msg.author.username});
     let menu = null;

     if(pokes.length == 6){
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
              { label: pokes[0].species, value: '0'},
              { label: pokes[1].species, value: '1'},
              { label: pokes[2].species, value: '2'},
              { label: pokes[3].species, value: '3'},
              { label: pokes[4].species, value: '4'},
              { label: pokes[5].species, value: '5'}
          ])
        );
     }
     else if (pokes.length == 5) {
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
            { label: pokes[0].species, value: '0'},
            { label: pokes[1].species, value: '1'},
            { label: pokes[2].species, value: '2'},
            { label: pokes[3].species, value: '3'},
            { label: pokes[4].species, value: '4'}
          ])
        );
     }

     else if (pokes.length == 4) {
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
            { label: pokes[0].species, value: '0'},
            { label: pokes[1].species, value: '1'},
            { label: pokes[2].species, value: '2'},
            { label: pokes[3].species, value: '3'}
          ])
        );
     }
     else if (pokes.length == 3) {
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
            { label: pokes[0].species, value: '0'},
            { label: pokes[1].species, value: '1'},
            { label: pokes[2].species, value: '2'}
          ])
        );
     }
     else if (pokes.length == 2) {
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
            { label: pokes[0].species, value: '0'},
            { label: pokes[1].species, value: '1'}
          ])
        );
     }
     else if (pokes.length == 1) {
        menu = new ActionRowBuilder().setComponents(
          new StringSelectMenuBuilder().setCustomId('party_list').setOptions([
              { label: pokes[0].species, value: '0'}
          ])
        );
     }
     else{
       client.channels.cache.get('1097227005818327140').send("Invalid Party Size");
     }

     const message = {
        content: "Select a pokemon",
        components: [menu],
       }
       client.channels.cache.get('1097227005818327140').send(message);
     }
     if(cont.startsWith('nickname') || cont.startsWith('Nickname')){

       const pokes = await testSchema.find({trainer : msg.author.username});
       let menu = null;

       let arr = cont.split(" ");
       if(arr.length != 2){
         client.channels.cache.get('1097227005818327140').send("Please enter a nickname");
       }
       else{
         nickname = arr[1];
         if(pokes.length == 6){
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_name').setOptions([
                  { label: pokes[0].species, value: '0'},
                  { label: pokes[1].species, value: '1'},
                  { label: pokes[2].species, value: '2'},
                  { label: pokes[3].species, value: '3'},
                  { label: pokes[4].species, value: '4'},
                  { label: pokes[5].species, value: '5'}
              ])
            );
         }
         else if (pokes.length == 5) {
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_names').setOptions([
                { label: pokes[0].species, value: '0'},
                { label: pokes[1].species, value: '1'},
                { label: pokes[2].species, value: '2'},
                { label: pokes[3].species, value: '3'},
                { label: pokes[4].species, value: '4'}
              ])
            );
         }

         else if (pokes.length == 4) {
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_name').setOptions([
                { label: pokes[0].species, value: '0'},
                { label: pokes[1].species, value: '1'},
                { label: pokes[2].species, value: '2'},
                { label: pokes[3].species, value: '3'}
              ])
            );
         }
         else if (pokes.length == 3) {
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_name').setOptions([
                { label: pokes[0].species, value: '0'},
                { label: pokes[1].species, value: '1'},
                { label: pokes[2].species, value: '2'}
              ])
            );
         }
         else if (pokes.length == 2) {
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_name').setOptions([
                { label: pokes[0].species, value: '0'},
                { label: pokes[1].species, value: '1'}
              ])
            );
         }
         else if (pokes.length == 1) {
            menu = new ActionRowBuilder().setComponents(
              new StringSelectMenuBuilder().setCustomId('party_name').setOptions([
                  { label: pokes[0].species, value: '0'}
              ])
            );
         }
         else{
           client.channels.cache.get('1097227005818327140').send("Invalid Party Size");
         }

         const message = {
            content: "Select a pokemon",
            components: [menu]
           }
           client.channels.cache.get('1097227005818327140').send(message);
         }
       }



   if(cont.startsWith("dm")){
     let arr = cont.split(" ");
     let m = "";
     for(let i = 1; i < arr.length; i++){
       m += arr[i];
       if(i == arr.length-1){
         m+= "!";
      }
      else{
        m+= " ";
      }
     }
     msg.author.send("You said " + m);
   }
   if(cont.startsWith("run")){
     let arr = cont.split(" ")
     let command = "";
    // try{
         for(let i = 1; i < arr.length; i++){
         command+= arr[i];
         if(i < arr.length-1) {
           command += " ";
         }
       }
       console.log(command);
       //t();
       var f = new Function(command);
       f();
    // }
    // catch{
    //   msg.reply("Invalid Code");
    // }
   }

   if(cont == "options" || cont == "Options"){
     msg.reply("1. DM a message\n2.Randomly generate a color  \n3.Randomly generate a food \n");
     client.on('messageCreate', msg => {
       switch(cont){
         case "1":
         msg.author.send("Water Bottle");
         break;
         case "2":
         let c = "#"
         let arr = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];
         for(let i = 0; i < 6; i++){
           j = Math.floor(Math.random() * 16);
           c+= arr[j];
         }
         msg.reply(c);
         break;
         case "3":
         msg.reply("Food")
         break;
       }
     });
   }

   if(cont.startsWith("bloxuser") && cont.includes(" ")){

     let arr = cont.split(" ");
     let val = arr[1];
     let req = 'https://users.roblox.com/v1/users/' + val;

     try{
       const results = await request(req);
       const nresults = await results.body.json();
       const myJSON = JSON.stringify(nresults);

       let arr1 = myJSON.split(",")
       let reply = ""

       reply = arr1[6].substring(8, arr1[6].length-1);
       msg.reply("The user you searched for has the name " + reply);
   }
    catch(error){
     msg.reply("No user found with that userID");
    }
   }
   if(cont == "random_color"){
     let c = "";
     let arr = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];
     for(let i = 0; i < 6; i++){
       j = Math.floor(Math.random() * 16);
       c += arr[j];
     }
     msg.channel.send({files: ["https://color.dyno.gg/color/"+ c + "/80x80.png"]});
   }
   if(cont.startsWith("set_nickname")){

     let arr = cont.split(" ");

     nickname = "";

     for(let i = 2; i < arr.length; i++){
       if(i == arr.length - 1){
         nickname += arr[i];
       }else{
         nickname += arr[i] + " ";
       }
     }

     let currName = arr[1];
     let capitalName = "";

     let f = currName.substring(0,1);
     let e = currName.substring(1);
     f = f.toUpperCase();
     capitalName = f + e;

     let c = (await testSchema.findOne({name : capitalName}));
     let n = (await testSchema.findOne({name : currName}));

     if(c != null){
       if(c.name != c.species){
         client.channels.cache.get('1097227005818327140').send("You changed " + capitalName + "'s " + "(" + c.species + ")" + " name to " + nickname + "!");
       }else{
         client.channels.cache.get('1097227005818327140').send("You changed " + capitalName + "'s name to " + nickname + "!");
       }
       await testSchema.updateOne({name : capitalName}, {$set: {name: nickname}});

     }
     if(n != null){
       if(n.name != n.species){
         client.channels.cache.get('1097227005818327140').send("You changed " + currName + "'s " + "(" + n.species + ")" + " name to " + nickname + "!");
       }else{
         client.channels.cache.get('1097227005818327140').send("You changed " + currName + "'s name to " + nickname + "!");
       }
       await testSchema.updateOne({name : currName}, {$set: {name: nickname}});

     }


   }

   if(cont.startsWith("debug")){
     generated = msg.author;
     let i = 58;

     let arr = cont.split(" ");
     if(arr.length > 1){
       i = arr[1];
     }

     let j = Math.floor(Math.random() * 100);

     let req = 'https://pokeapi.co/api/v2/pokemon/' + i;

     const results = await request(req);
     const nresults = await results.body.json();
     const myJSON = JSON.stringify(nresults);

     let arr1 = myJSON.split(",")

     let fl = ""

     let type1 = "";
     let type2 = "";

     for(let i = 0; i < arr1.length; i++){
       if(arr1[i].substring(1,6) === "forms"){
         name = arr1[i].substring(18, arr1[i].length-1);
         fl = name.substring(0,1);
         fl = fl.toUpperCase();
         name = fl + name.substring(1);
       }
       if(arr1[i].substring(0,6) === '"type"'){
         if(type1 == ""){
           type1 = arr1[i].substring(16, arr1[i].length-1);
           fl = type1.substring(0,1);
           fl = fl.toUpperCase();
           type1 = fl + type1.substring(1);
         }else{
           type2 = arr1[i].substring(16, arr1[i].length-1);
           fl = type2.substring(0,1);
           fl = fl.toUpperCase();
           type2 = fl + type2.substring(1);
         }
         if(type2 == ""){
           type = type1;
         }else{
           type = type1 + "/" + type2;
         }

         const natureNum = Math.floor(Math.random() * 25);
         const nature = natures[natureNum];

         new testSchema({
           name: name,
           species: name,
           typing: type,
           shiny: shinyBool,
           evs: evsarr,
           ivs: ivsarr,
           nature: nature,
           level: "50",
           trainer: msg.author.username,
         }).save()

         client.channels.cache.get('1097227005818327140').send("You caught " + name + "!");

       }
     }

     const poke_embed = {
      title: name,
      description: 'Typing: ' + type,
      image: {
       url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+ i +'.png',
     },
     footer: {
      text: "Type '-catch' to throw a pokeball",
    },
    };
    const shiny_embed = {
     title: name,
     description: 'Typing: ' + type,
     image: {
       url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/'+ i +'.png',
     },
     footer: {
      text: "Type '-catch' to throw a pokeball",
    },
   };

    if(j == 50){
      shinyBool = true;
      client.channels.cache.get('1097227005818327140').send({ embeds: [shiny_embed], ephemeral: true });
    } else {
      client.channels.cache.get('1097227005818327140').send({ embeds: [poke_embed], ephemeral: true });
    }

   }

   if(cont.startsWith("release") ||  cont.startsWith("Release")){
     let arr = cont.split(" ");
     let name = "";
     if(arr.length == 2)  name = arr[1];
     else if (arr.length > 2) {
       for(let i = 1; i < arr.length; i++){
         if(i == 1) name = arr[1]
         else {
           let x = arr[i].substring(0,1);
           let y = arr[i].substring(1);
           x = x.toUpperCase();
           name += " " + x + y;
         }
       }
     }


     const pokes = await testSchema.find({trainer : msg.author.username});

     let f = name.substring(0,1);
     let e = name.substring(1);
     f = f.toUpperCase();
     name = f + e;

     let released = false;
     for(let i = 0; i < pokes.length; i++){
       if(pokes[i].name == name) {
         released = true;
         await testSchema.findOneAndDelete({name : arr[1]});
         if(pokes[i].shiny == true){
           client.channels.cache.get('1097227005818327140').send("You released Shiny " + name + "! Bye bye " + name + "!  :wave:");
         }else{
           client.channels.cache.get('1097227005818327140').send("You released " + name + "! Bye bye " + name + "!  :wave:");
         }
       }
    }
    if(released == false) client.channels.cache.get('1097227005818327140').send("No pokemon found named " + name);

   }
   if(cont == 'party'){
     const pokes = await testSchema.find({trainer : msg.author.username});
     let lst = "";

     for(let i = 0; i < pokes.length; i++){

       if(pokes[i].name != pokes[i].species){
        /* const poke_embed = {
          title: pokes[0].name,
          description: 'Typing: ' + pokes[0].type,
          image: {
           url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+ pokes[i].number +'.png',
         },
       }
        client.channels.cache.get('1097227005818327140').send({ embeds: [poke_embed], ephemeral: true });*/
          if(i == pokes.length - 1){
            lst = lst + pokes[i].name + " (" + pokes[i].species + ")";
          }else{
            lst = lst + pokes[i].name + " (" + pokes[i].species + ")" + ", ";
          }
        }else{
          if(i == pokes.length - 1){
            lst = lst + pokes[i].name;
          }else{
            lst = lst + pokes[i].name + ", ";
          }
        }

     }
     client.channels.cache.get('1097227005818327140').send(lst);



   }
    //client.channels.cache.get('1097227005818327140').send({ embeds: [poke_embed], ephemeral: true });

   if(cont == 'Buttons' || cont == 'buttons'){
     const pokeball = new ButtonBuilder()
     .setCustomId('pokeball')
     .setLabel('PokeBall')
     .setStyle(ButtonStyle.Danger);

     const greatball = new ButtonBuilder()
     .setCustomId('great')
     .setLabel('Great Ball')
     .setStyle(ButtonStyle.Primary);

     const ultraball = new ButtonBuilder()
     .setCustomId('ultra')
     .setLabel('Ultra Ball')
     .setStyle(ButtonStyle.Secondary);


   const row = new ActionRowBuilder()
     .addComponents(pokeball, greatball, ultraball);

     const messageObject = {
       content: "Click a button",
       components: [row]
     }
      client.channels.cache.get('1097227005818327140').send(messageObject);
   }
   if(cont == 'Catch' || cont == 'catch'){
     if(msg.author == generated){
       const pokeball = new ButtonBuilder()
       .setCustomId('pokeball')
       .setEmoji('<:pokeball:1157515551585878136>')
       .setLabel('PokeBall')
       .setStyle(ButtonStyle.Danger);

       const greatball = new ButtonBuilder()
       .setCustomId('great')
       .setEmoji('<:greatball:1162164415102189590>')
       .setLabel('Great Ball')
       .setStyle(ButtonStyle.Primary);

       const ultraball = new ButtonBuilder()
       .setCustomId('ultra')
       .setEmoji('<:ultraball:1157517047723470888>')
       .setLabel('Ultra Ball')
       .setStyle(ButtonStyle.Secondary);

       const premierball = new ButtonBuilder()
       .setCustomId('premier')
       .setEmoji('<:premierBall:1187547953930436778>')
       .setLabel('Premier Ball')
       .setStyle(ButtonStyle.Danger);

       const masterball = new ButtonBuilder()
       .setCustomId('master')
       .setEmoji('<:masterBall:1179942257307172914>')
       .setLabel('Master Ball')
       .setStyle(ButtonStyle.Success);

     const row = new ActionRowBuilder()
       .addComponents(pokeball, greatball, ultraball, premierball, masterball);

       const messageObject = {
         content: "Click a ball type",
         components: [row]
       }
        client.channels.cache.get('1097227005818327140').send(messageObject);
       /*const pokes = await testSchema.find({trainer : msg.author.username});
       const natureNum = Math.floor(Math.random() * 25);
       const nature = natures[natureNum];
       if(name != ""){
         let r = Math.random()*10;
         if(pokes.length < 6){
           if(r > 0){
             new testSchema({
               name: name,
               species: name,
               typing: type,
               shiny: shinyBool,
               evs: evsarr,
               ivs: ivsarr,
               nature: nature,
               trainer: msg.author.username,
             }).save()
             client.channels.cache.get('1097227005818327140').send("You caught " + name + "!");
             name = "";
             generated = "";
           }else{
             client.channels.cache.get('1097227005818327140').send("You failed to catch " + name + "!");
             name = "";
             generated = "";
           }
         }else{
           client.channels.cache.get('1097227005818327140').send("You already have a full party!");
         }

       }else{
         client.channels.cache.get('1097227005818327140').send("Catch what?");
       }*/
     }else{
       client.channels.cache.get('1097227005818327140').send("Catch what?");
     }
   }
   if(cont.includes("_poke")){

     generated = msg.author;
     arr = await player.find({name : msg.author.username});
     let p = arr[0];
     let numc = parseInt(p.coins);
     let cost = 0;
    if(cont.includes("early")){
      cost = 0;
    }
    if(cont.includes("random")){
      cost = 100;
    }
    if(cont.includes("strong")){
      cost = 500;
    }
    if(numc >= cost){
      let c = numc
      c = c - cost;
      await player.updateOne({name : msg.author.username}, {$set: {coins: parseInt(c)}});

       let n = Math.floor(Math.random() * 25);
       nature = natures[n];

       hpiv = Math.floor(Math.random() * 32);
       attiv = Math.floor(Math.random() * 32);
       deffiv = Math.floor(Math.random() * 32);
       spattiv = Math.floor(Math.random() * 32);
       spdefiv = Math.floor(Math.random() * 32);
       speediv = Math.floor(Math.random() * 32);

       ivsarr = [hpiv, attiv, deffiv, spattiv, spdefiv, speediv];

       //var x = setInterval(async function(){
          let i = 0;
          let j = 0;
          let d = 0;
          let ds = 0;
          let s = 0;
         if(cont.includes("random")){
           i = Math.floor(Math.random() * 1010) + 1;
           j = Math.floor(Math.random() * 450);
           d = Math.floor(Math.random() * 100);
           ds = Math.floor(Math.random() * 50);
         }
         if(cont.includes("early")){
           j = Math.floor(Math.random() * 450);
           s = Math.floor(Math.random() * 100);
           i = earlypokes[Math.floor(Math.random() * 40)];
           if(s == 50){
             i = 494;
           }
         }
         if(cont.includes("strong")){
           let r = Math.random(Math.floor(Math.random() * 21));
           i = strongpokes[r];
           s = Math.floor(Math.random() * 100);
           j = Math.floor(Math.random() * 450);
           if(s == 50){
             i = 807;
           }
         }

         let req = 'https://pokeapi.co/api/v2/pokemon/' + i;
         number = i;

         const results = await request(req);
         const nresults = await results.body.json();
         const myJSON = JSON.stringify(nresults);

         let arr1 = myJSON.split(",")

         let fl = ""
         let type1 = "";
         let type2 = "";

         for(let i = 0; i < arr1.length; i++){
           if(arr1[i].substring(1,6) === "forms"){
             name = arr1[i].substring(18, arr1[i].length-1);
             fl = name.substring(0,1);
             fl = fl.toUpperCase();
             name = fl + name.substring(1);
           }
           if(arr1[i].substring(0,6) === '"type"'){
             if(type1 == ""){
               type1 = arr1[i].substring(16, arr1[i].length-1);
               fl = type1.substring(0,1);
               fl = fl.toUpperCase();
               type1 = fl + type1.substring(1);
             }else{
               type2 = arr1[i].substring(16, arr1[i].length-1);
               fl = type2.substring(0,1);
               fl = fl.toUpperCase();
               type2 = fl + type2.substring(1);
             }
             if(type2 == ""){
               type = type1;
             }else{
               type = type1 + "/" + type2;
             }

           }
         }
         const poke_embed = {
          title: name,
          description: 'Typing: ' + type,
          image: {
           url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+ i +'.png',
         },
         footer: {
       		text: "Type '-catch' to throw a pokeball",
       	},
        };
        const shiny_embed = {
         title: name,
         description: 'Typing: ' + type,
         image: {
           url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/'+ i +'.png',
         },
         footer: {
       		text: "Type '-catch' to throw a pokeball",
       	},
       };

        if(j == 2){
          shinyBool = true;
          client.channels.cache.get('1097227005818327140').send({ embeds: [shiny_embed], ephemeral: true });
        } else {
          client.channels.cache.get('1097227005818327140').send({ embeds: [poke_embed], ephemeral: true });
        }
        if(d == 50){
          name = "Ditto";
          type = "Normal";
          number = "132";
          if(ds == 30){
            shinyBool = true;
          }
        }

     }
     else{
       client.channels.cache.get('1097227005818327140').send("Not enough coins");
     }
   }
    //  counter++;

      //if(counter == num) {
      //  clearInterval(x);
      //}
  //  }, 1000);

    //client.on('messageCreate', async msg => {

  //  });
  //}

   /*if(msg.content.startsWith("mineuser") && msg.content.includes(" ")){

     let arr = msg.content.split(" ");
     let val = arr[1];
     let req = 'https://minotar.net/avatar/' + val;

     try{




   }
    catch(error){
     msg.reply("No user found with that userID");
    }
  }*/
   if(cont == "embed"){
    client.channels.cache.get('1097227005818327140').send({ embeds: [exampleEmbed], ephemeral: true });
   }

   if(cont == "modEmbed"){
     msg.reply("1. Change Color\n2. Change Title  \n3. Change Descriptions \n");
     client.on('messageCreate', msg => {
       let val = cont.split(" ");
       if(val[1] != null){
         switch(val[0]){
           case "1":
           exampleEmbed.color = val[1];
           client.channels.cache.get('1097227005818327140').send({ embeds: [exampleEmbed] });
           break;
           case "2":
           exampleEmbed.title = val[1];
           client.channels.cache.get('1097227005818327140').send({ embeds: [exampleEmbed] });
           break;
           case "3":
           exampleEmbed.description = val[1];
           client.channels.cache.get('1097227005818327140').send({ embeds: [exampleEmbed] });
           break;
         }
       }
     });
   }
   /*if(msg.content == "button"){
     const {ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder}  = require('discord.js');

     module.exports = {
  	// data: new SlashCommandBuilder()...
  	async execute(interaction) {
  		const target = interaction.options.getUser('target');
  		const reason = interaction.options.getString('reason') ?? 'No reason provided';

  		const confirm = new ButtonBuilder()
  			.setCustomId('confirm')
  			.setLabel('Confirm Ban')
  			.setStyle(ButtonStyle.Danger);

  		const cancel = new ButtonBuilder()
  			.setCustomId('cancel')
  			.setLabel('Cancel')
  			.setStyle(ButtonStyle.Secondary);

  		const row = new ActionRowBuilder()
  			.addComponents(cancel, confirm);

  		await interaction.reply({
  			content: `Are you sure you want to ban ${target} for reason: ${reason}?`,
  			components: [row],
  		});
  	},
  };
  } */


 }

});

//client.on(Events.InteractionCreate, async interaction => {
client.on('interactionCreate', async interaction => {
	/*if (!interaction.isChatInputCommand()) return;
	const { commandName } = interaction;
  if(commandName === 'hey'){
    interaction.reply("Hey")*/

  //if(!interaction.isButton()) return;
    if(interaction.customId.startsWith("party_n")){
      pokes = await testSchema.find({trainer : interaction.user.username});
      let partyNumber = interaction.values[0];

      let spec = pokes[partyNumber].species;
      spec = spec.toLowerCase();

      let f = spec.substring(0,1);
      let e = spec.substring(1);
      f = f.toUpperCase();
      spec = f + e;

      //let n = (await testSchema.findOne({species : spec}));

      await testSchema.updateOne({species : spec}, {$set: {name: nickname}});

      interaction.reply({
        content: "You changed " + spec + "'s name to " + nickname + "!",
        ephemeral: true
      });



    }
    if(interaction.customId.startsWith("party_l")){

      pokes = await testSchema.find({trainer : interaction.user.username});
      let partyNumber = interaction.values[0];

      let spec = pokes[partyNumber].species;
      spec = spec.toLowerCase();

      let fl = "";
      let type1 = "";
      let type2 = "";

      let req = 'https://pokeapi.co/api/v2/pokemon/' + spec;

      const results = await request(req);
      const nresults = await results.body.json();
      const myJSON = JSON.stringify(nresults);

      let arr1 = myJSON.split(",")
      let natnum = nresults.id;

      let stats = ["", "", "", "", "", ""];
      let counter = 0;
      for(let j = 0; j< arr1.length; j++){
        if(arr1[j].includes("base_stat")){
          if(arr1[j].length > 16){
            stats[counter] = arr1[j].substring(22);
            counter++;
          }else{
            stats[counter] = arr1[j].substring(13);
            counter++;
          }

        }
        if(arr1[j].substring(0,6) === '"type"'){
          if(type1 == ""){
            type1 = arr1[j].substring(16, arr1[j].length-1);
            fl = type1.substring(0,1);
            fl = fl.toUpperCase();
            type1 = fl + type1.substring(1);
          }else{
            type2 = arr1[j].substring(16, arr1[j].length-1);
            fl = type2.substring(0,1);
            fl = fl.toUpperCase();
            type2 = fl + type2.substring(1);
          }
          if(type2 == ""){
            type = type1;
          }else{
            type = type1 + "/" + type2;
          }

        }

      }
      let mon = pokes[partyNumber];
      name = pokes[partyNumber].name;

      let natArray = [1, 1, 1, 1, 1];
      if(attack.includes(pokes[partyNumber].nature)){
        natArray[0] = 1.1;
      }
      if(mattack.includes(pokes[partyNumber].nature)){
        natArray[0] = 0.9;
      }
      if(deffense.includes(pokes[partyNumber].nature)){
        natArray[1] = 1.1;
      }
      if(mdeffense.includes(pokes[partyNumber].nature)){
        natArray[1] = 0.9;
      }
      if(spattack.includes(pokes[partyNumber].nature)){
        natArray[2] = 1.1;
      }
      if(mspattack.includes(pokes[partyNumber].nature)){
        natArray[2] = 0.9;
      }
      if(spdeff.includes(pokes[partyNumber].nature)){
        natArray[3] = 1.1;
      }
      if(mspdeff.includes(pokes[partyNumber].nature)){
        natArray[3] = 0.9;
      }
      if(speed.includes(pokes[partyNumber].nature)){
        natArray[4] = 1.1;
      }
      if(mspeed.includes(pokes[partyNumber].nature)){
        natArray[4] = 0.9;
      }
      let lev = parseInt(mon.level)
      let hp = Math.floor(0.01 * (2 * stats[0] + mon.ivs[0] + Math.floor(0.25 * 0)) * lev) + lev + 10;
      let att= Math.floor(((((2 * stats[1] + (mon.ivs[1] + 0)) * lev)/100) + 5) * natArray[0]);
      let def = Math.floor(((((2 * stats[2] + (mon.ivs[2] + 0)) * lev)/100) + 5) * natArray[1]);
      let spatt = Math.floor(((((2 * stats[3] + (mon.ivs[3] + 0)) * lev)/100) + 5) * natArray[2]);
      let spdef = Math.floor(((((2 * stats[4] + (mon.ivs[4] + 0)) * lev)/100) + 5) * natArray[3]);
      let spe = Math.floor(((((2 * stats[5] + (mon.ivs[5] + 0)) * lev)/100) + 5) * natArray[4]);

      const poke_embed = {
       title: name,
       description: 'Typing: ' + type + '\nLevel: ' + mon.level,
       thumbnail: {
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+ natnum +'.png',
      },
      fields: [
		{
			name: 'Stats',
			value: "Hp: " + hp + "\nAttack: " + att + "\nDefense: " + def + "\nSpe. Attack: " + spatt + "\nSpe. Defense: " + spdef + "\nSpeed: " + spe,
		},
	],
     };
     const shiny_embed = {
      title: name,
      description: 'Typing: ' + type,
      thumbnail: {
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/'+ natnum +'.png',
      },
      fields: [
		{
			name: 'Stats',
			value: "Hp: " + hp + "\nAttack: " + att + "\nDeffense: " + def + "\nSpe. Attack: " + spatt + "\nSpe. Deffense: " + spdef + "\nSpeed: " + spe,
		},
	],
    };

      if(pokes[partyNumber].shiny == true){
        interaction.reply({
          embeds: [shiny_embed],
          ephemeral: true
        });
      }else{
        interaction.reply({
          embeds: [poke_embed],
          ephemeral: true
        });
      }


    }
    if(interaction.customId.startsWith("Grass") || interaction.customId.startsWith("Water") || interaction.customId.startsWith("Fire")){
      if(interaction.customId.startsWith("Grass")){
        starter = starters[(startergen-1)*3]
      }
      if(interaction.customId.startsWith("Fire")){
        starter = starters[(startergen-1)*3 + 1]
      }
      if(interaction.customId.startsWith("Water")){
        starter = starters[(startergen-1)*3 + 2]
      }
      starter = starter.toLowerCase();

      let n = Math.floor(Math.random() * 25);
      nature = natures[n];

      hpiv = Math.floor(Math.random() * 32);
      attiv = Math.floor(Math.random() * 32);
      deffiv = Math.floor(Math.random() * 32);
      spattiv = Math.floor(Math.random() * 32);
      spdefiv = Math.floor(Math.random() * 32);
      speediv = Math.floor(Math.random() * 32);

      ivsarr = [hpiv, attiv, deffiv, spattiv, spdefiv, speediv];

        let j = Math.floor(Math.random() * 450);

        let req = 'https://pokeapi.co/api/v2/pokemon/' + starter;

        const results = await request(req);
        const nresults = await results.body.json();
        const myJSON = JSON.stringify(nresults);

        let arr1 = myJSON.split(",")

        let fl = ""
        let type1 = "";
        let type2 = "";

        for(let i = 0; i < arr1.length; i++){
          if(arr1[i].substring(1,6) === "forms"){
            name = arr1[i].substring(18, arr1[i].length-1);
            fl = name.substring(0,1);
            fl = fl.toUpperCase();
            name = fl + name.substring(1);
          }
          if(arr1[i].substring(0,6) === '"type"'){
            if(type1 == ""){
              type1 = arr1[i].substring(16, arr1[i].length-1);
              fl = type1.substring(0,1);
              fl = fl.toUpperCase();
              type1 = fl + type1.substring(1);
            }else{
              type2 = arr1[i].substring(16, arr1[i].length-1);
              fl = type2.substring(0,1);
              fl = fl.toUpperCase();
              type2 = fl + type2.substring(1);
            }
            if(type2 == ""){
              type = type1;
            }else{
              type = type1 + "/" + type2;
            }

          }
        }
        const poke_embed = {
         title: name,
         description: 'Typing: ' + type,
         image: {
          url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+ nresults.id +'.png',
        },
        footer: {
         text: "You got your first pokemon!",
       },
       };
       const shiny_embed = {
        title: name,
        description: 'Typing: ' + type,
        image: {
          url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/'+ nresults.id +'.png',
        },
        footer: {
         text: "You got your first pokemon!",
       },
      };

       if(j == 2){
         shinyBool = true;
         interaction.reply({
           embeds: [shiny_embed],
           ephemeral: true
         });
       }else{
         interaction.reply({
           embeds: [poke_embed],
           ephemeral: true
         });
       }

        new testSchema({
          name: name,
          species: name,
          typing: type,
          shiny: shinyBool,
          evs: evsarr,
          ivs: ivsarr,
          nature: nature,
          trainer: interaction.user.username,
          number: nresults.id,
          level: '5',
        }).save()
    }
    if(interaction.customId.startsWith("pokeball") || interaction.customId.startsWith("premier")){
      let crit = Math.floor(Math.random() * 10);
      const pokes = await testSchema.find({trainer : interaction.user.username});
      const natureNum = Math.floor(Math.random() * 25);
      const nature = natures[natureNum];
      if(name != ""){
        let r = Math.random()*10;
        if(pokes.length < 6){
          if(crit == 5){
            if(r > 4){
              new testSchema({
                name: name,
                species: name,
                typing: type,
                shiny: shinyBool,
                evs: evsarr,
                ivs: ivsarr,
                nature: nature,
                trainer: interaction.user.username,
                number: number,
                level: "50",
              }).save()
              interaction.reply({
                content: "You caught " + name + " with a critical capture!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }
            else{
              interaction.reply({
                content: "You failed to catch " + name + " even with a critical capture!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }
          }
          else{
            if(r > 7){
            new testSchema({
              name: name,
              species: name,
              typing: type,
              shiny: shinyBool,
              evs: evsarr,
              ivs: ivsarr,
              nature: nature,
              trainer: interaction.user.username,
              number: number,
              level: "50",
            }).save()
            interaction.reply({
              content: "You caught " + name + "!",
              ephemeral: true
            });
            name = "";
            generated = "";
          }
          else{
            interaction.reply({
              content: "You failed to catch " + name + "!",
              ephemeral: true
            });
            name = "";
            generated = "";
          }
        }
        }else{
          interaction.reply({
            content: "You already have a full party!",
            ephemeral: true
          });
        }

      }else{
        client.channels.cache.get('1097227005818327140').send("Catch what?");
      }
    }
    if(interaction.customId.startsWith("great")){
        let crit = Math.floor(Math.random() * 10);
        const pokes = await testSchema.find({trainer : interaction.user.username});
        const natureNum = Math.floor(Math.random() * 25);
        const nature = natures[natureNum];
        if(name != ""){
          let r = Math.random()*10;
          if(pokes.length < 6){
            if(crit == 5){
              if(r > 2){
                new testSchema({
                  name: name,
                  species: name,
                  typing: type,
                  shiny: shinyBool,
                  evs: evsarr,
                  ivs: ivsarr,
                  nature: nature,
                  trainer: interaction.user.username,
                  number: number,
                  level: "50"
                }).save()
                interaction.reply({
                  content: "You caught " + name + " with a critical capture!",
                  ephemeral: true
                });
                name = "";
                generated = "";
              }
              else{
                interaction.reply({
                  content: "You failed to catch " + name + " even with a critical capture!",
                  ephemeral: true
                });
                name = "";
                generated = "";
              }
            }
            else{
              if(r > 5){
              new testSchema({
                name: name,
                species: name,
                typing: type,
                shiny: shinyBool,
                evs: evsarr,
                ivs: ivsarr,
                nature: nature,
                trainer: interaction.user.username,
                number: number,
                level: "50",
              }).save()
              interaction.reply({
                content: "You caught " + name + "!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }else{
              interaction.reply({
                content: "You failed to catch " + name + "!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }
          }
          }else{
            interaction.reply({
              content: "You already have a full party!",
              ephemeral: true
            });
          }

        }else{
          client.channels.cache.get('1097227005818327140').send("Catch what?");
        }

    }
    if(interaction.customId.startsWith("ultra")){
        let crit = Math.floor(Math.random() * 10);
        const pokes = await testSchema.find({trainer : interaction.user.username});
        const natureNum = Math.floor(Math.random() * 25);
        const nature = natures[natureNum];
        if(name != ""){
          let r = Math.random()*10;
          if(pokes.length < 6){
            if(crit == 5){
              if(r > 4){
                new testSchema({
                  name: name,
                  species: name,
                  typing: type,
                  shiny: shinyBool,
                  evs: evsarr,
                  ivs: ivsarr,
                  nature: nature,
                  trainer: interaction.user.username,
                  number: number,
                  level: "50",
                }).save()
                interaction.reply({
                  content: "You caught " + name + " with a critical capture!",
                  ephemeral: true
                });
                name = "";
                generated = "";
              }
              else{
                interaction.reply({
                  content: "You failed to catch " + name + " even with a critical capture!",
                  ephemeral: true
                });
                name = "";
                generated = "";
              }
            }
            else{
              if(r > 7){
              new testSchema({
                name: name,
                species: name,
                typing: type,
                shiny: shinyBool,
                evs: evsarr,
                ivs: ivsarr,
                nature: nature,
                trainer: interaction.user.username,
                number: number,
                level: "50",
              }).save()
              interaction.reply({
                content: "You caught " + name + "!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }
            else{
              interaction.reply({
                content: "You failed to catch " + name + "!",
                ephemeral: true
              });
              name = "";
              generated = "";
            }
          }
          }else{
            interaction.reply({
              content: "You already have a full party!",
              ephemeral: true
            });
          }

        }else{
          client.channels.cache.get('1097227005818327140').send("Catch what?");
        }
      }

    if(interaction.customId.startsWith('master')){
        const pokes = await testSchema.find({trainer : interaction.user.username});
        const natureNum = Math.floor(Math.random() * 25);
        const nature = natures[natureNum];
        if(name != ""){
          let r = Math.random()*10;
          if(pokes.length < 6){
            if(r > 0){
              new testSchema({
                name: name,
                species: name,
                typing: type,
                shiny: shinyBool,
                evs: evsarr,
                ivs: ivsarr,
                nature: nature,
                trainer: interaction.user.username,
                number: number,
                level: "50",
              }).save()
              interaction.reply({
                content: "You caught " + name + "!",
                ephemeral: true
              });
              //client.channels.cache.get('1097227005818327140').send("You caught " + name + "!");
              name = "";
              generated = "";
            }else{
              interaction.reply({
                content: "You failed to catch " + name + "!",
                ephemeral: true
              });
              //client.channels.cache.get('1097227005818327140').send("You failed to catch " + name + "!");
              name = "";
              generated = "";
            }
          }else{
            interaction.reply({
              content: "You already have a full party!",
              ephemeral: true
            });
            //client.channels.cache.get('1097227005818327140').send("You already have a full party!");
          }

        }else{
          client.channels.cache.get('1097227005818327140').send("Catch what?");
        }
    }

	// ...
});

//make sure this line is the last line
client.login(process.env.CLIENT_TOKEN); //login bot using token
